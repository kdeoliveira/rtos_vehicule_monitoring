/****************************************************************************
** Generated QML type registration code
**
** WARNING! All changes made in this file will be lost!
*****************************************************************************/

#include <QtQml/qqml.h>
#include <QtQml/qqmlmoduleregistration.h>


void qml_register_types_qnx_rtos()
{
    qmlRegisterModule("qnx.rtos", 1, 0);
}

static const QQmlModuleRegistration registration("qnx.rtos", 1, qml_register_types_qnx_rtos);
