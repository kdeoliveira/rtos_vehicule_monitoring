#include "reader.h"

//Reader::Reader(int fd, QObject *parent) : QThread(parent), m_file_descriptor{fd}
//{
//    this->m_abort = false;
//}



//void Reader::run() {
//    char* rcv;

//    while( read(this->m_file_descriptor, &rcv, sizeof(float)) > 0 ){
//        float temp = (float) atof(rcv);
//        emit bufferRead(temp);
//    }
//}




